import hashlib
import hmac
import secrets
import re

def hash_password(password):
    salt = secrets.token_bytes(16)
    hashed = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt, 200000
    )
    return salt.hex() + "$" + hashed.hex()

def verify_password(password, stored):
    salt_hex, hash_hex = stored.split("$")
    salt = bytes.fromhex(salt_hex)
    expected = bytes.fromhex(hash_hex)
    actual = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt, 200000
    )
    return hmac.compare_digest(actual, expected)

def validate_username(username):
    if len(username) < 3:
        return False, "Username must be at least 3 characters."
    if not re.fullmatch(r"[a-zA-Z0-9_]+", username):
        return False, "Use only letters, numbers, and underscores."
    return True, ""

def validate_email(email):
    if not re.fullmatch(r"[\w.-]+@[\w.-]+\.\w+", email):
        return False, "Enter a valid email address."
    return True, ""

def validate_password(password):
    if len(password) < 8:
        return False, "Password must be at least 8 characters."
    if not any(char.isdigit() for char in password):
        return False, "Password must contain a number."
    if not any(char.isalpha() for char in password):
        return False, "Password must contain a letter."
    return True, ""