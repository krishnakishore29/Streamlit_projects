import pandas as pd
import streamlit as st

from auth import (
    hash_password,
    verify_password,
    validate_username,
    validate_email,
    validate_password,
)
from db import init_db, create_user, get_user_by_username, get_all_users

st.set_page_config(page_title="Login and Sign Up", page_icon="🔐")
st.title("Login and Sign Up")
st.caption("Student: P Krishna Kishore | PRN: 250200194")
st.info("Local demo database: accounts are stored on this computer.")

init_db()

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "login_attempts" not in st.session_state:
    st.session_state.login_attempts = 0

if st.session_state.logged_in:
    user = st.session_state.user
    st.success(f"Welcome, {user['username']}!")

    st.subheader("Registered Users")
    users = get_all_users()
    st.dataframe(pd.DataFrame([dict(row) for row in users]))

    if st.button("Logout"):
        st.session_state.logged_in = False
        st.rerun()

else:
    login_tab, signup_tab = st.tabs(["Login", "Sign Up"])

    with login_tab:
        st.subheader("Login")

        with st.form("login_form"):
            username = st.text_input("Username", key="login_username")
            password = st.text_input(
                "Password", type="password", key="login_password"
            )
            login = st.form_submit_button("Login")

        if login:
            user = get_user_by_username(username)

            if user and verify_password(password, user["password_hash"]):
                st.session_state.logged_in = True
                st.session_state.user = dict(user)
                st.session_state.login_attempts = 0
                st.rerun()
            else:
                st.session_state.login_attempts += 1
                st.error(
                    f"Invalid login. Attempt "
                    f"{st.session_state.login_attempts} of 3."
                )

    with signup_tab:
        st.subheader("Create Account")

        with st.form("signup_form"):
            new_username = st.text_input("Choose a username")
            email = st.text_input("Email")
            new_password = st.text_input(
                "Choose a password", type="password"
            )
            confirm_password = st.text_input(
                "Confirm password", type="password"
            )
            signup = st.form_submit_button("Sign Up")

        if signup:
            valid, message = validate_username(new_username)

            if not valid:
                st.error(message)
            else:
                valid, message = validate_email(email)

                if not valid:
                    st.error(message)
                else:
                    valid, message = validate_password(new_password)

                    if not valid:
                        st.error(message)
                    elif new_password != confirm_password:
                        st.error("The passwords do not match.")
                    else:
                        created = create_user(
                            new_username,
                            email,
                            hash_password(new_password),
                        )

                        if created:
                            st.success("Account created. Now log in.")
                        else:
                            st.error("That username or email is already used.")