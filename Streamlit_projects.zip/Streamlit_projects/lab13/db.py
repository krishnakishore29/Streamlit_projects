import sqlite3
from pathlib import Path

DATABASE = Path(__file__).with_name("users.db")

def get_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection

def init_db():
    with get_connection() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL
            )
        """)

def create_user(username, email, password_hash):
    try:
        with get_connection() as connection:
            connection.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
                (username, email, password_hash),
            )
        return True
    except sqlite3.IntegrityError:
        return False

def get_user_by_username(username):
    with get_connection() as connection:
        return connection.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()

def get_all_users():
    with get_connection() as connection:
        return connection.execute(
            "SELECT id, username, email FROM users ORDER BY id"
        ).fetchall()