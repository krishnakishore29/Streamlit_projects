import streamlit as st

st.set_page_config(page_title="Weather API Demo", page_icon="🌤️")
st.title("Weather API Demo")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

city = st.text_input("Enter city", "Chennai")

if st.button("Get Weather"):
    # Simulated example response; no API key is needed.
    weather = {
        "city": city,
        "temperature": 30,
        "condition": "Sunny",
        "humidity": 65,
    }

    st.info("This is a simulated weather response.")

    st.json(weather)

    col1, col2, col3 = st.columns(3)
    col1.metric("Temperature", f"{weather['temperature']} °C")
    col2.metric("Condition", weather["condition"])
    col3.metric("Humidity", f"{weather['humidity']}%")

st.subheader("HTTP Methods")
st.write("GET - Retrieve data")
st.write("POST - Send data")
st.write("PUT - Update data")
st.write("DELETE - Delete data")