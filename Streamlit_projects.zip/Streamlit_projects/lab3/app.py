import streamlit as st

st.set_page_config(page_title="Layouts Demo", layout="wide")
st.title("Layouts Demo")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

st.sidebar.header("Settings")
theme = st.sidebar.selectbox("Theme", ["Light", "Dark"])
font_size = st.sidebar.slider("Font Size", 10, 30, 15)

col1, col2 = st.columns(2)

with col1:
    st.metric("Total Sales", "25 Lakh")

with col2:
    st.metric("Customers", "1,200")

tab1, tab2, tab3 = st.tabs(["Overview", "Analysis", "About"])

with tab1:
    st.write("Overview of the sample business metrics.")
    st.bar_chart({"Monthly sales": [18, 24, 21, 29]})

with tab2:
    st.write("Analysis of monthly sales.")
    st.line_chart({"Monthly sales": [18, 24, 21, 29]})

with tab3:
    st.write("A compact demonstration of Streamlit layouts.")

with st.container(border=True):
    st.subheader("Grouped Section")
    st.write(f"Theme: {theme}")
    st.write(f"Selected font size: {font_size}")
    st.write("These items are grouped inside a container.")

with st.expander("Details"):
    st.write("This section is hidden until you expand it.")