import streamlit as st
import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier

st.set_page_config(page_title="Iris Flower Prediction")
st.title("Iris Flower Prediction")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

# Load the Iris dataset and train a model
iris = load_iris()
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(iris.data, iris.target)

class_names = iris.target_names

if "history" not in st.session_state:
    st.session_state.history = []

with st.form("prediction_form"):
    sepal_length = st.slider("Sepal Length (cm)", 4.0, 8.0, 5.1)
    sepal_width = st.slider("Sepal Width (cm)", 2.0, 4.5, 3.5)
    petal_length = st.slider("Petal Length (cm)", 1.0, 7.0, 1.4)
    petal_width = st.slider("Petal Width (cm)", 0.1, 2.5, 0.2)

    submit = st.form_submit_button("Predict")

if submit:
    features = np.array([[
        sepal_length,
        sepal_width,
        petal_length,
        petal_width,
    ]])

    prediction = model.predict(features)[0]
    probabilities = model.predict_proba(features)[0]

    predicted_class = class_names[prediction]

    st.success(f"Prediction: {predicted_class.title()}")
    st.metric("Confidence", f"{max(probabilities) * 100:.1f}%")

    probability_data = pd.DataFrame(
        {"Probability": probabilities},
        index=[name.title() for name in class_names],
    )
    st.subheader("Class Probabilities")
    st.bar_chart(probability_data)

    st.session_state.history.append({
        "Sepal Length": sepal_length,
        "Sepal Width": sepal_width,
        "Petal Length": petal_length,
        "Petal Width": petal_width,
        "Prediction": predicted_class.title(),
    })

st.subheader("Prediction History")

if st.session_state.history:
    st.dataframe(pd.DataFrame(st.session_state.history))
else:
    st.write("Submit the form to record a prediction.")