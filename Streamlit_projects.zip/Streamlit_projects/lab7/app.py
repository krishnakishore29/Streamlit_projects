import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Sales Dashboard", layout="wide")
st.title("Sales Dashboard")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

# Create repeatable sample sales data
rng = np.random.default_rng(7)
dates = pd.date_range("2024-01-01", periods=120, freq="D")

df = pd.DataFrame({
    "Date": rng.choice(dates, 200),
    "Region": rng.choice(["North", "South", "East", "West"], 200),
    "Product": rng.choice(["A", "B", "C"], 200),
    "Sales": rng.integers(1000, 10000, 200),
})

st.sidebar.header("Filters")
regions = st.sidebar.multiselect(
    "Region", sorted(df["Region"].unique()), default=sorted(df["Region"].unique())
)
products = st.sidebar.multiselect(
    "Product", sorted(df["Product"].unique()), default=sorted(df["Product"].unique())
)

filtered = df[
    df["Region"].isin(regions) & df["Product"].isin(products)
]

col1, col2, col3 = st.columns(3)
col1.metric("Total Sales", f"₹{filtered['Sales'].sum():,}")
col2.metric(
    "Average Sale",
    f"₹{filtered['Sales'].mean():,.0f}" if not filtered.empty else "₹0",
)
col3.metric("Records", len(filtered))

left, right = st.columns(2)

with left:
    st.subheader("Sales by Region")
    st.bar_chart(filtered.groupby("Region")["Sales"].sum())

with right:
    st.subheader("Sales by Product")
    st.bar_chart(filtered.groupby("Product")["Sales"].sum())

st.subheader("Sales Over Time")
daily_sales = filtered.groupby("Date")["Sales"].sum().sort_index()
st.line_chart(daily_sales)

st.download_button(
    "Download Filtered CSV",
    data=filtered.to_csv(index=False).encode("utf-8"),
    file_name="filtered_sales.csv",
    mime="text/csv",
)