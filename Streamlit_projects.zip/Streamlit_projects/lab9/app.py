import streamlit as st

st.set_page_config(page_title="Simple Chatbot", page_icon="💬")
st.title("Simple Chatbot")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hi! Ask me about Python or Streamlit."}
    ]

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

prompt = st.chat_input("Type your message...")

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})

    if "python" in prompt.lower():
        reply = "Python is popular for AI and data science."
    elif "streamlit" in prompt.lower():
        reply = "Streamlit is a Python framework for interactive web apps."
    else:
        reply = f"You said: {prompt}. I'm a demo chatbot!"

    st.session_state.messages.append(
        {"role": "assistant", "content": reply}
    )
    st.rerun()

if st.session_state.messages:
    chat_text = "\n".join(
        f"{message['role'].title()}: {message['content']}"
        for message in st.session_state.messages
    )
    st.download_button(
        "Download Chat History",
        chat_text,
        "chat_history.txt",
        "text/plain",
    )

if st.button("Clear Chat"):
    st.session_state.messages = []
    st.rerun()