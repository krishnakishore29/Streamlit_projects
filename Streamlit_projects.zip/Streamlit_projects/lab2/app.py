import streamlit as st
from datetime import date

st.set_page_config(page_title="Widgets Playground")
st.title("Widgets Playground")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

name = st.text_input("Name", "P Krishna Kishore")
age = st.number_input("Age", min_value=1, max_value=100, value=20)
marks = st.slider("Marks", min_value=0, max_value=100, value=75)
city = st.selectbox("City", ["Chennai", "Mumbai", "Delhi"])
skills = st.multiselect("Skills", ["Python", "ML", "SQL", "Streamlit"])
gender = st.radio("Gender", ["Male", "Female", "Other"])
agree = st.checkbox("I agree to terms")
dob = st.date_input("Date of Birth", date(2000, 1, 1))
uploaded_file = st.file_uploader("Upload a file")

color = st.color_picker("Pick a color", "#00AA88")
marks_range = st.select_slider(
    "Select a range of marks",
    options=list(range(101)),
    value=(40, 80),
)

if st.button("Submit"):
    st.subheader("Submitted values")
    st.write("Name:", name)
    st.write("Age:", age)
    st.write("Marks:", marks)
    st.write("City:", city)
    st.write("Skills:", skills)
    st.write("Gender:", gender)
    st.write("Agreed:", agree)
    st.write("Date of Birth:", dob)
    st.write(
        "File:",
        uploaded_file.name if uploaded_file else "No file uploaded",
    )
    st.write("Color:", color)
    st.write("Marks range:", marks_range)