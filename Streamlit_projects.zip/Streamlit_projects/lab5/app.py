import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Data Visualization", layout="wide")
st.title("Data Visualization")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

# Sample marks for 20 students
rng = np.random.default_rng(42)
data = rng.normal(70, 12, size=(20, 3)).clip(0, 100)

df = pd.DataFrame(
    data,
    columns=["Math", "Science", "English"]
)

st.metric("Average Math Score", f"{df['Math'].mean():.1f}")

st.subheader("Line Chart")
st.line_chart(df)

st.subheader("Bar Chart")
st.bar_chart(df)

st.subheader("Area Chart")
st.area_chart(df)

st.subheader("Math Score Distribution")
fig, ax = plt.subplots()
ax.hist(df["Math"], bins=10, color="skyblue", edgecolor="black")
ax.set_title("Math Score Distribution")
ax.set_xlabel("Math Score")
ax.set_ylabel("Number of Students")
st.pyplot(fig)

st.subheader("Math and Science Relationship")
st.scatter_chart(df, x="Math", y="Science")