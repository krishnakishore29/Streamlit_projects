from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(page_title="CSV Explorer", layout="wide")
st.title("Upload CSV and Analyze")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
else:
    # Use the sample file in this lab folder until you upload another CSV.
    sample_file = Path(__file__).parent / "students.csv"
    if sample_file.exists():
        df = pd.read_csv(sample_file)
        st.info("Showing the sample data. Upload a CSV to analyze your own file.")
    else:
        st.warning("Upload a CSV file to begin.")
        st.stop()

st.subheader("Data Preview")
st.dataframe(df, use_container_width=True)

st.subheader("Statistics")
st.dataframe(df.describe(include="all").fillna("-"), use_container_width=True)

st.subheader("Missing Values")
st.write(df.isna().sum())

handle_missing = st.radio(
    "Handle missing values",
    ["Keep", "Drop", "Fill with 0"],
    horizontal=True,
)

if handle_missing == "Drop":
    df = df.dropna()
elif handle_missing == "Fill with 0":
    df = df.fillna(0)

column = st.selectbox("Choose a column to filter", df.columns)
search = st.text_input("Filter value")

if search:
    filtered_df = df[
        df[column].astype(str).str.contains(search, case=False, na=False)
    ]
else:
    filtered_df = df

st.subheader("Filtered Data")
st.dataframe(filtered_df, use_container_width=True)

sort_column = st.selectbox("Sort by", df.columns, key="sort")
st.subheader("Sorted Data")
st.dataframe(df.sort_values(sort_column), use_container_width=True)

numeric_columns = df.select_dtypes(include="number").columns

if len(numeric_columns) > 0:
    group_column = st.selectbox("Group by", df.columns, key="group")
    st.subheader("Grouped Averages")
    grouped = df.groupby(group_column)[numeric_columns].mean()
    st.dataframe(grouped, use_container_width=True)

st.download_button(
    "Download Processed CSV",
    data=df.to_csv(index=False).encode("utf-8"),
    file_name="processed.csv",
    mime="text/csv",
)