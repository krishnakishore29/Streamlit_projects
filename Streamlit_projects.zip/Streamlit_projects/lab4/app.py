import streamlit as st

st.set_page_config(page_title="Forms and Session State")
st.title("Forms + Session State")
st.caption("Student: P Krishna Kishore | PRN: 250200194")

if "count" not in st.session_state:
    st.session_state.count = 0

col1, col2, col3 = st.columns(3)

if col1.button("Increment"):
    st.session_state.count += 1

if col2.button("Add 5"):
    st.session_state.count += 5

if col3.button("Reset"):
    st.session_state.count = 0

st.metric("Counter", st.session_state.count)

with st.form("login_form"):
    st.subheader("Login")
    username = st.text_input("Username", "admin")
    password = st.text_input("Password", type="password", value="1234")
    submitted = st.form_submit_button("Login")

if submitted:
    if username == "admin" and password == "1234":
        st.session_state.logged_in = True
        st.success("Login successful!")
    else:
        st.error("Invalid credentials.")

if st.session_state.get("logged_in", False):
    st.info("Welcome, admin! You are now logged in.")

st.subheader("To-do list")

if "todos" not in st.session_state:
    st.session_state.todos = []

with st.form("todo_form", clear_on_submit=True):
    task = st.text_input("New task")
    add_task = st.form_submit_button("Add task")

if add_task and task.strip():
    st.session_state.todos.append(task.strip())

for number, todo in enumerate(st.session_state.todos, start=1):
    st.write(f"{number}. {todo}")

if st.button("Clear all tasks"):
    st.session_state.todos = []